# Sample LaTeX project report (student template)

This folder is a **complete sample** term-project report for TFSE.  
It demonstrates structure, dual-book citations, numeric examples, and honesty about SAMPLE data.

## Compile

```bash
cd term-project/sample-report
pdflatex main.tex
bibtex main
pdflatex main.tex
pdflatex main.tex
```

Or with `latexmk`:

```bash
latexmk -pdf main.tex
```

## How students should use it

1. Copy this folder into your team repo as `report/` (or keep Overleaf).  
2. Replace SAMPLE names, theme (G1–G7), numbers, and figures with **your** evidence.  
3. Do **not** submit this sample unchanged — that is academic misconduct.  
4. Keep section order; you may shorten appendices if your instructor allows.  
5. Figures: export diagrams from your `docs/` pack (PNG/PDF) into `figures/`.

## Files

| File | Role |
| --- | --- |
| `main.tex` | Full report body |
| `refs.bib` | Bibliography (course-aligned real venues) |
| `figures/.gitkeep` | Place your diagrams here |
